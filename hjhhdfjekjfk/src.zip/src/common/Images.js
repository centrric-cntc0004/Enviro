import EnviroLogo from '../Assets/Images/Icons/enviro_logo.png'
import ClientImage from '../Assets/Images/Icons/ClientImage.png'
import TeamImage from '../Assets/Images/Icons/Team.png'
import CertificateImage from '../Assets/Images/Icons/certificate.png'
import MapImage from '../Assets/Images/Icons/map.png'
import LocationImage from '../Assets/Images/Icons/location.png'
import VehicleImage from '../Assets/Images/Icons/vehicle.jpg'


export {
    EnviroLogo,
    ClientImage,
    TeamImage,
    CertificateImage,
    MapImage,
    LocationImage,
    VehicleImage
}
