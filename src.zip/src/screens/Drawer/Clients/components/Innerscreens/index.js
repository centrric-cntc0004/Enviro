import MapViews from './MapViews'
import AddDetails from './AddDetails'
import PreviousSales from './PreviousSales'
import ProfileData from './ProfileData'
import ProfileDataC from './ProfileDataC'
import AddDetailsC from './AddDetailsC'
import AddDetailsEdit from './AddDetailsEdit'
import ProfileDataEdit from './ProfileDataEdit'

import PickLocation from './PickLocation'
export {ProfileDataEdit,AddDetailsEdit, MapViews, AddDetails, PreviousSales, ProfileData, PickLocation,AddDetailsC,ProfileDataC }