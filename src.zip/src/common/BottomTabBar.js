import React from 'react'
import { View, Text, TouchableOpacity, Dimensions } from 'react-native'
import Icon from 'react-native-vector-icons/dist/MaterialIcons';
import Icon1 from 'react-native-vector-icons/MaterialCommunityIcons';
import { lightGrey, } from './Colors'


function EnviroBottomTabBar({ state, descriptors, navigation }) {
  return (

    <View >
     
    </View>
  )
}


export default EnviroBottomTabBar
