import ContentLayout from './ContentLayout'

export {ContentLayout}